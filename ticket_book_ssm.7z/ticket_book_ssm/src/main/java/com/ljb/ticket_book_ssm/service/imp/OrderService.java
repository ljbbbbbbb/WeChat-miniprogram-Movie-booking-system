package com.ljb.ticket_book_ssm.service.imp;

import com.ljb.ticket_book_ssm.dao.ICinemaDao;
import com.ljb.ticket_book_ssm.dao.IOrderDao;
import com.ljb.ticket_book_ssm.entity.Order;
import com.ljb.ticket_book_ssm.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
@Service
public class OrderService implements IOrderService {
    @Autowired
    private IOrderDao iOrderDao;
    @Autowired
    private ICinemaDao iCinemaDao;
    /**
     * 查看订单
     * @param openId
     * @param page
     * @return
     */
    public List<Map<String, Object>> getUserOrderByOpenId(String openId, int page){

        return iOrderDao.getUserOrderByOpenId(openId,(page-1)*10,page*10);

    }

    /**
     * 查看订单详情
     * @param orderId
     * @return
     */
    public Map<String, Object> getOrderDetailByOrderId(String openId,int orderId){
        //查看该用户是否存在订了该订单
        Integer ifExist = iOrderDao.findOrderIdIfExistedByOrderIdAndOpenId(openId,orderId);
        return iOrderDao.getOrderDetailByOrderId(ifExist);
    }
    /**
     * 查看被订座位
     * @param sid
     * @return
     */
    public List<Map<String, Object>> getPurchasedSeat(int sid){
        List<Map<String, Object>> resultMap= null;
        resultMap = iOrderDao.getPurchasedSeat(sid);
        return resultMap;

    }
    /**
     * 生成订单查看该场次的信息
     * @param sid
     * @return 1有 0没有
     */
    public Map<String, Object> checkShow(int sid){
        Map<String, Object> resultMap= null;
        resultMap = iCinemaDao.checkShow(sid);
        return resultMap;


    }
    /**
     * 订票
     * @param order
     * @return -1:没有该场次电影 0:票已经被订，1：订票成功
     */
    public Map<String, Object> bookTicket(Order order){
        //查看该电影场次的数据。
        Map<String, Object> showMap = this.checkShow(order.getS_id());

        if(showMap == null || order.getU_openid() == null){
            return null;
        }

        //生成取票码
        //int ttcode = (int) ((Math.random()*9+1)*100000);

        String orderCode = showMap.get("start_time")+ String.format("%07d%s%02d", order.getS_id(),order.getRow(),order.getColumn());
        //order.setTt_code(0);
        order.setOrder_code(orderCode);
        Object price = showMap.get("price");
        order.setPrice(Float.parseFloat((String.valueOf(price))));
        //验证票是否已经被订 orderStatus查过3代表没有目前没有被订
        Integer orderStatus = iOrderDao.findOrderStatusByOrderCode(order.getOrder_code());
        if (orderStatus == null){
            orderStatus  = 6;
        }
        if(orderStatus > 3){
            //生成订单
            //order.setOrder_status(1);
            //获取当前时间
            //Date now = new Date();
            //order.setCreate_time(now);
            iOrderDao.save(order);
            Map<String, Object> orderMap = iOrderDao.getOrderDetailByOrderId(order.getOrder_id());
            return orderMap;
        }else {
            return null;
        }
    }
    /**
     * 申请退票
     * @param openId
     * @param orderCode
     * @return 1 申请成功，0：申请失败 2退款失败
     */
    public int applyForRefund(String openId,String orderCode){
        int orderId = iOrderDao.findOrderId(openId,orderCode);

        if(iOrderDao.updateOrderStatus(orderId,4) == 1){
            //退款
            if (iOrderDao.refund(orderId) == 1){
                return 1;
            }
            return 2;
        }
        return 0;
    }

    /**
     * 支付
     * @param openId
     * @param orderCode
     * @return -1订单状态不是已订未付状态、0、订单异常，1支付成功、2无法生成取票码但支付成功
     */
    public int payForTicket(String openId,String orderCode){
        //查看该订单的订单状态，如果不是已经订了未付状态
        //该订单的订单状态
        Integer orderStatus = iOrderDao.findOrderStatusByOpenIdAndOrderCode(openId,orderCode);
        if (orderStatus != 1){
            return -1;
        }
        Integer orderId = iOrderDao.findOrderId(openId,orderCode);
        //{付钱}
        if(iOrderDao.updateOrderStatus(orderId,2) == 1){
            //生成取票码
            int ttcode = (int) ((Math.random()*9+1)*100000);
            int ttcodeStatus = iOrderDao.payForTicket(orderId,ttcode);
            if (ttcodeStatus == 1){
                return 1;
            }
            return 2;
        }
        return 0;
    }
    /**
     * 退款(实现不了,这个本该是在售票管理系统实现的)
     * @param openId
     * @param orderCode
     * @return
     */
    public int refund(String openId,String orderCode){
        Integer orderId = iOrderDao.findOrderId(openId,orderCode);
        if (orderId == null){
            return -1;
        }
        if(iOrderDao.refund(orderId) == 1){
            return 1;
        }
        return 0;
    }
}
