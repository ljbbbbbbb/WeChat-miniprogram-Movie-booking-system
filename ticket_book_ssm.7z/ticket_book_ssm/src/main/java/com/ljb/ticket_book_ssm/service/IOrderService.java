package com.ljb.ticket_book_ssm.service;

import com.ljb.ticket_book_ssm.entity.Order;

import java.util.List;
import java.util.Map;


public interface IOrderService {
    /**
     * 查看订单
     * @param openId
     * @param page
     * @return
     */
    List<Map<String, Object>> getUserOrderByOpenId(String openId, int page);

    /**
     * 查看订单详情
     * @param orderId
     * @return
     */
    Map<String, Object> getOrderDetailByOrderId(String openId,int orderId);
    /**
     * 查看场次被订座位
     * @param sid
     * @return
     */
    List<Map<String, Object>> getPurchasedSeat(int sid);
    /**
     * 查看场次信息
     * @param sid
     * @return
     */
    Map<String, Object> checkShow(int sid);
    /**
     * 订票
     * @param order
     * @return 0:票已经被订，1：订票成功 -1:订票失败
     */
    Map<String, Object> bookTicket(Order order);
    /**
     * 申请退票
     * @param openId
     * @param orderCode
     * @return 1 申请成功，申请失败
     */
    int applyForRefund(String openId,String orderCode);

    int payForTicket(String openId,String orderCode);

}
