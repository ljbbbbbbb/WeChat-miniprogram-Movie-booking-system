package com.ljb.ticket_book_ssm.controller;

import com.alibaba.fastjson.JSON;
import com.ljb.ticket_book_ssm.entity.Order;
import com.ljb.ticket_book_ssm.entity.Users;
import com.ljb.ticket_book_ssm.service.IOrderService;
import com.ljb.ticket_book_ssm.service.IUserService;
import com.ljb.ticket_book_ssm.util.AuthUtil;
import net.sf.json.JSONObject;
import org.apache.catalina.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/user",headers = "Accept=application/json;charset=UTF-8")
public class UserController {
    @Value("${login.backUrl}")
    private String backUrl;
    @Autowired
    private IUserService iUserService;
    @Autowired
    private IOrderService iOrderService;

    @RequestMapping("/login")
    public String login(){
        //回调链接
        //String backUrl=backUrl;
        //String backUrl="http://www.fenghongzhang.com/WeChat2048/CallBackServlet";
        //请求链接

        String url="http://open.weixin.qq.com/connect/oauth2/authorize?appid="+ AuthUtil.APPID+
                "&redirect_uri="+ URLEncoder.encode(backUrl)+
                "&response_type=code"+
                "&scope=snsapi_userinfo"+
                "&state=STATE#wechat_redirect";
        //response.sendRedirect(url);
        return "redirect:"+url;
    }

    @RequestMapping("/callBack")
    @ResponseBody
    public Object callBack(Model model, String code,String user) throws IOException {
        com.alibaba.fastjson.JSONObject userInfo = JSON.parseObject(user);
        //System.out.println("code"+userInfo);
        String url = "https://api.weixin.qq.com/sns/jscode2session?" +
                "appid=" +AuthUtil.APPID+
                "&secret=" + AuthUtil.APPSECRET+
                "&js_code=" + code+
                "&scope=snsapi_userinfo"+
                "&grant_type=authorization_code";
        JSONObject jsonObject=AuthUtil.doGetJson(url);
        System.out.println(jsonObject);
        /*
        url="https://api.weixin.qq.com/sns/oauth2/access_token?appid="+AuthUtil.APPID+
                "&secret="+ AuthUtil.APPSECRET+
                "&code="+code+
                "&scope=snsapi_userinfo"+
                "&grant_type=authorization_code";


        //JSONObject jsonObject=AuthUtil.doGetJson(url);
        System.out.println("2"+jsonObject);

        String openid=jsonObject.getString("openid");
        String token=jsonObject.getString("access_token");
        String inforUrl="https://api.weixin.qq.com/sns/userinfo?"+
                "access_token="+token+
                "&openid="+openid+
                "&lang=zh_CN";
        JSONObject userInfo=AuthUtil.doGetJson(inforUrl);


         */
        userInfo.put("openid",(String)jsonObject.get("openid"));

        Users users  = new Users((String)jsonObject.get("openid"),
                (String)userInfo.get("nickName"),
                (Integer) userInfo.get("gender"),
                (String)userInfo.get("language"),
                (String)userInfo.get("city"),
                (String)userInfo.get("province"),
                (String)userInfo.get("country"),
                (String)userInfo.get("avatarUrl"));

        iUserService.register(users);
        model.addAttribute("user",userInfo);
        return userInfo;


    }

    @RequestMapping("/getOrder")
    @ResponseBody
    //查看订单
    public List<Map<String, Object>> getUserOrderByOpenId(String openId, int page){
        return iOrderService.getUserOrderByOpenId(openId,page);
    }
    @RequestMapping("/getOrderDetail")
    @ResponseBody
    //查看订单详情
    public Map<String, Object> getOrderDetail(String openId,int orderId){
        return iOrderService.getOrderDetailByOrderId(openId,orderId);
    }
    //订票
    @RequestMapping("/book")
    @ResponseBody
    public Map<String, Object> bookTicket(Order order){

        return iOrderService.bookTicket(order);
    }
    //申请退票
    @RequestMapping("/applyForRefund")
    @ResponseBody
    public Map<String, Object> applyForRefund(HttpServletResponse response, String openId, String orderCode) {
        int status = iOrderService.applyForRefund(openId,orderCode);
        Map<String, Object> resultMap = new HashMap<String,Object>();
        resultMap.put("code",response.getStatus());
        resultMap.put("timestamp",new Date().getTime());
        if (status == 1){
            resultMap.put("status",1);
        }else if (status == 2){
            resultMap.put("status",2);
        } else{
            resultMap.put("status",0);
        }
        return resultMap;
    }
    //支付
    @RequestMapping("/payForTicket")
    @ResponseBody
    public Map<String, Object> payForTicket(HttpServletResponse response, String openId, String orderCode) {

        int status = iOrderService.payForTicket(openId,orderCode);
        Map<String, Object> resultMap =  new HashMap<String,Object>();
        resultMap.put("code",response.getStatus());
        resultMap.put("timestamp",new Date().getTime());
        if (status ==1){
            resultMap.put("status",1);
        }else {
            resultMap.put("status",0);
        }


        return resultMap;
    }
    //寻找附近影院
    @RequestMapping(value = "/getLocalCinema")
    @ResponseBody
    public List<Map<String, Object>> findNearCinemaByLL(double lon, double lat, int page){
        return iUserService.findNearCinemaByLL(lon,lat,page);
    }
    //查看被订座位
    @RequestMapping(value = "/getPurchasedSeat")
    @ResponseBody
    public List<Map<String, Object>> getPurchasedSeat(int sid){
        return iOrderService.getPurchasedSeat(sid);
    }

}
