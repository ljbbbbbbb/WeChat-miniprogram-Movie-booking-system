package com.ljb.ticket_book_ssm.service;

import com.ljb.ticket_book_ssm.entity.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
public class OrderTest {
    @Autowired
    private IOrderService iOrderService;
    @Test
    void getUserOrderByOpenId(){
        System.out.println(iOrderService.getUserOrderByOpenId("123",1));
    }
    @Test
    void getOrderDetailByOrderId(){
        System.out.println(iOrderService.getOrderDetailByOrderId("oyE6jwzWX7f-DX0N2JymNtfh-6G8",90));
    }
    @Test
    void getPurchasedSeat(){
        System.out.println(iOrderService.getPurchasedSeat(4976));
    }
    @Test
    void bookTicket(){

        Order order = new Order(9036,2,2,"oyE6jwzWX7f-DX0N2JymNtfh-6G8",null,null,null,null,0);

        System.out.println(iOrderService.bookTicket(order));


    }
    @Test
    void payForTicket(){
        System.out.println(iOrderService.payForTicket("oyE6jwzWX7f-DX0N2JymNtfh-6G8","202006290815000009036202"));
    }
    @Test
    void applyForRefund(){
        System.out.println(iOrderService.applyForRefund("oyE6jwzWX7f-DX0N2JymNtfh-6G8","202006290815000009036202"));
    }
    @Test
    void refund(){
        System.out.println(iOrderService.applyForRefund("1","12312"));
    }
}
