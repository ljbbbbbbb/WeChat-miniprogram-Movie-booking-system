package com.ljb.ticket_book_ssm.entity;

public class Log {

}
