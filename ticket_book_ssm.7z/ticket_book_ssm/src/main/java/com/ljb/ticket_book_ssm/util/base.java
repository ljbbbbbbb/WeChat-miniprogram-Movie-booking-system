package com.ljb.ticket_book_ssm.util;

import com.ljb.ticket_book_ssm.entity.Order;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class base{
    public List<Map<String, Object>> MySQLDateToUtilDateListMap(List<Map<String, Object>> mapList,String dateKey,String format){
        if (mapList == null){
            return null;
        }
        for (Map<String, Object> map : mapList) {
            if(map.get(dateKey) == null){
                continue;
            }
            //由于sql的date和util的date不一样，会报错，所以换成String
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            String date = sdf.format(map.get(dateKey));
            map.remove(dateKey);
            map.put(dateKey, date);
        }
        return mapList;
    }
    public Map<String, Object> MySQLDateToUtilDateMap(Map<String, Object> map,String dateKey,String format){
        //由于sql的date和util的date不一样，会报错，所以换成String
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String date = sdf.format(map.get(dateKey));
        map.remove(dateKey);
        map.put(dateKey, date);
        return map;
    }
    /*电影Map改造。将String以’,'切割成字符串数组，目标分别是"actor,role,a_href,photo_href"
     并且把actor,role,a_href合成actor{actorName=*,role=*,a_href=*},*/
    public Map<String, Object> MoviesMapReform(Map<String, Object> resultMap){
        if (resultMap == null){
            return null;
        }
        String[] keySet = {"actor","role","a_href","photo_href"};
        //先把需要切割的字符串提出来
        for (String key : keySet) {
            String str = (String) resultMap.get(key);
            if(str == null){
                continue;
            }
            String[] strSplit = str.split(",");
            resultMap.put(key, strSplit);
        }

        return resultMap;
    }

    //获取当前时间轴，request的状态码
    public JSONObject setResultJson(int status,JSONArray jsonArray){
        JSONObject resultJson = new JSONObject();
        resultJson.accumulate("code",status);
        resultJson.accumulate("timestamp",new Date().getTime());
        resultJson.accumulate("data",jsonArray);
        return resultJson;
    }
    private double rad(double d) {
            return d * Math.PI / 180.0;
        }
    /**
     * 计算两个经纬度之间的距离
     *
     * @param lat1
     * @param lng1
     * @param lat2
     * @param lng2
     * @return km
     */
    public double getDistance(double lat1, double lng1, double lat2, double lng2) {
        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double a = radLat1 - radLat2;
        double b = rad(lng1) - rad(lng2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) +
                    Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
        double EARTH_RADIUS = 6378.137;
        s = s * EARTH_RADIUS;
        DecimalFormat df = new DecimalFormat("#.000");
        s = Double.parseDouble(df.format(s));
        //返回距离默认为km，如果需要其他单位请记得换算
        return s;
        }

    /**
     * 日期加减
     * @param dateTime
     * @param n
     * @return
     */
    public java.sql.Date addAndSubtractDaysByGetTime(Date dateTime/*待处理的日期*/, int n/*加减天数*/) throws ParseException {

        //日期格式
        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
        //SimpleDateFormat dd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //System.out.println(df.format(new Date(dateTime.getTime() + n * 24 * 60 * 60 * 1000L)));
        //System.out.println(dd.format(new Date(dateTime.getTime() + n * 24 * 60 * 60 * 1000L)));
        //注意这里一定要转换成Long类型，要不n超过25时会出现范围溢出，从而得不到想要的日期值
        // 时间加减并解析回util.date形式
        Date date = df.parse(df.format(new Date(dateTime.getTime() + n * 24 * 60 * 60 * 1000L)));

        // 将当前时间转化为sql时间
        return new java.sql.Date(date.getTime());
    }

}
