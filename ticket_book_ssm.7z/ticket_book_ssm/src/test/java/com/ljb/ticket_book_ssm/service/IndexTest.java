package com.ljb.ticket_book_ssm.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndexTest {
    @Autowired
    private IIndexService iIndexService;

    @Test
    void getMoviesByPage(){
        //获取正在上映电影
        System.out.println(iIndexService.getMoviesByPage(1,2));
        //获取即将上映的电影
        System.out.println(iIndexService.getMoviesByPage(1,1));
    }
    @Test
    void searchMoviesByName(){
        System.out.println(iIndexService.searchMoviesByName("中"));
    }
    @Test
    void searchCinemaByLL(){
        System.out.println(iIndexService.searchCinemaByLL("青",113.46488,23.25535,1));
    }
    @Test
    void getMovieDetailByMid(){
        System.out.println(iIndexService.getMovieDetailByMid(1));
    }
    @Test
    void getMovieScheduleByCid(){
        System.out.println(iIndexService.getCinemaScheduleByCid(2));
    }

    @Test
    void getCinemaScheduleByMid(){
        System.out.println(iIndexService.getCinemaScheduleByMid(1189,113.46488,23.16535));
    }
}
