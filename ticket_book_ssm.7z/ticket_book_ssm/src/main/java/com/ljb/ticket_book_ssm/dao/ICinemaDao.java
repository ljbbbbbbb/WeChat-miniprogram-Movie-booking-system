package com.ljb.ticket_book_ssm.dao;

import com.ljb.ticket_book_ssm.entity.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Mapper
@Repository
public interface ICinemaDao {
    /**
     * 根据经纬度查询附近影院
     * @param lon
     * @param lat
     * @param page
     * @return
     */
    List<Map<String, Object>> findCinemaByLL(@Param("lon") double lon,
                                             @Param("lat") double lat,
                                             @Param("page") int page,
                                             @Param("pageIndex") int pageIndex);

    /**
     * 搜搜附近影院
     * @param cName
     * @param lon
     * @param lat
     * @param page
     * @return
     */
    List<Map<String, Object>> searchCinemaByLL(@Param("cName") String cName,
                                               @Param("lon") double lon,
                                             @Param("lat") double lat,
                                             @Param("page") int page,
                                             @Param("pageIndex") int pageIndex);


    /**
     * 验证场次的正确性
     * @param sid
     * @return 1正确 0错误
     */
    Map<String, Object> checkShow(int sid);
}
