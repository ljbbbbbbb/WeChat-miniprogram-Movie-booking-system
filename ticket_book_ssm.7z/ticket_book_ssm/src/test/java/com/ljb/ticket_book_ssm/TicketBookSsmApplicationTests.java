package com.ljb.ticket_book_ssm;

import com.ljb.ticket_book_ssm.dao.ICinemaDao;
import com.ljb.ticket_book_ssm.dao.IMovieDao;
import com.ljb.ticket_book_ssm.dao.IOrderDao;
import com.ljb.ticket_book_ssm.dao.IUserDao;
import com.ljb.ticket_book_ssm.entity.Order;
import com.ljb.ticket_book_ssm.entity.Users;
import com.ljb.ticket_book_ssm.service.IIndexService;
import com.ljb.ticket_book_ssm.util.base;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;
import com.ljb.ticket_book_ssm.util.AesCbcUtil;
@SpringBootTest(classes = TicketBookSsmApplication.class)
class TicketBookSsmApplicationTests extends base {
    @Autowired
    private IUserDao iUserDao;
    @Autowired
    private IMovieDao iMovieDao;
    @Autowired
    private ICinemaDao iCinemaDao;
    @Autowired
    private IOrderDao iOrderDao;
    @Test
    @Transactional
    void findOpenid(){
        iUserDao.save(new Users("124","123",123,"123","123","123","123","123"));
        System.out.println(iUserDao.findOpenIdIfExisted("123"));
        //iUserDao.save(new Users("124","123",123,"123","123","123","123","123"));
        System.out.println(iUserDao.findUserByOpenId("123"));
    }
    @Test
    void movie() throws ParseException {
        //System.out.println(iMovieDao.findMovieIfExistedByCName("电影中文12名字_0"));
        //System.out.println(iMovieDao.getMovieDetailByMid(2));
        //System.out.println(iMovieDao.getMoviesByPage(1,10,1));
        //System.out.println(iMovieDao.searchMovieByCName("中"));
        System.out.println(iMovieDao.findMovieByCidAndDate(1,
                addAndSubtractDaysByGetTime(new Date(),0),
                addAndSubtractDaysByGetTime(new Date(),3)));
    }
    @Test
    void cinema() {
        //System.out.println(iCinemaDao.findCinemaByLL(113.46488,23.15535,0,10));
        /*System.out.println(iCinemaDao.findMovieByCidAndDate(1,
                addAndSubtractDaysByGetTime(new Date(),0),
                addAndSubtractDaysByGetTime(new Date(),1)));

         */
        //System.out.println(iCinemaDao.test("电影中文名字_0"));
        Order order = new Order(2,2,2,"123","123",new Date(),null,null,(float)77.7);

    }
    @Test
    void order(){
        //System.out.println(iOrderDao.findOrderIdIfExisted(1));
        //System.out.println(iOrderDao.getUserOrderByOpenId("1",0,10));

        Order order = new Order(3001,2,2,"123","123",new Date(),null,null,(float)77.7);


        //String orderCode = order.getOrder_code();
        //System.out.println(orderCode);

        //System.out.println(iOrderDao.findOrderCode(orderCode));

        //iOrderDao.save(order);
        Integer orderId = iOrderDao.findOrderId("oyE6jwzWX7f-DX0N2JymNtfh-6G8","202006280815000008976508");
        System.out.println(orderId);
        System.out.println(iOrderDao.updateOrderStatus(orderId,2));

    }
    @Value("${login.backUrl}")
    private String backUrl;
    @Test
    void envir(){
        System.out.println(backUrl);
    }

    @Test
    void UtilTest() throws Exception {
        String encryptedData = "1ZJceZx53RRoonuZDyfN4MCBPb4x5Of4IAbnf2E9WUa4PZzs1iip0WfWCjZT9Jtfpa5czbVKSdLN9sCihAz8e15YJK0ad9o6El8vN7ftQVlyuWtvPUVyVEPmg78yswif3rk6cXvksGmdofyjipS0MdOFwh5Ejakqyit8YELYJJKz5O2glTLut79v1/EWaPYy4Kyh4pH+Kck4NxCoUmu5esEPrLGQvRLp2R0mCwsCLjxaWZUKsviYRw3QsLfmn1TOpoU7zozPp5GkBM4gMM0SfPIWXCySFp3sj5xxBN+Om8/IprmSuvK0XAnR9f3N+kdLKAknFwI9AlgfxIawp2inP9AZvFRmpxUAvrpxfm3zBrEHGfwzRrlybMSUpbE7DbPXHoVusME57fkv0SGHuCjJum1cabGC1TvVI9gEeDSIz6martAilJnRnWaGPey5kjDtJlGPgjH3LKHMLwbmYbdq9GzyyvTu0W2T6Y0T8ucBc3c=";
        String iv = "xUsS7+yZKIYinZAkGgSERw==";
        //解密
        String result = AesCbcUtil.decrypt(encryptedData,"/tITfljiQ2z0kWoUZ224Lw==",iv,"UTF-8");
        System.out.println(result);
    }
}
