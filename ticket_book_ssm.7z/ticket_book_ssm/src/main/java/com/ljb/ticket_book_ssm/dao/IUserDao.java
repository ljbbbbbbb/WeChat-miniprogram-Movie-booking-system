package com.ljb.ticket_book_ssm.dao;

import com.ljb.ticket_book_ssm.entity.Users;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface IUserDao {
    /**
     * 寻找用户openip，判断用户是否存在
     * @param OpenId
     * @return True：代表用户存在； false：代表用户不存在
     */
    String findOpenIdIfExisted(String OpenId);
    /**
     * 查询用户信息
     * @param OpenId
     * @return Users对象
     */
    Users findUserByOpenId(String OpenId);
    /**
     * 注册
     * @param u
     * @return 1：注册成功 ，0：注册失败
     */
    void save(Users u);

    /**
     * 更新订单状态
     * @param Openid
     * @param orderCode
     * @return
     */
    int updateOrderStatus(String Openid, String orderCode, int OrderStatus);
}
