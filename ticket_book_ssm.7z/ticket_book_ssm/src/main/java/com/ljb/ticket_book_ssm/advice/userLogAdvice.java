package com.ljb.ticket_book_ssm.advice;

import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;

import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;


@Aspect
@Order(1)
@Component
public class userLogAdvice {
    private Logger logger = Logger.getLogger(userLogAdvice.class);
    @Pointcut("execution(public * com.ljb.ticket_book_ssm.controller.*.*(..))")
    public void initPointCut(){
        //nothing
    }
    /*
    添加日志
     */
    @Before("initPointCut()")
    public void preLog(JoinPoint jp){
        Map<String,Object> preLog = new HashMap<>();
        //.getSignature 是获取方法名
        //获取连接点的方法签名对象,在该对象中可以获取到目标方法名,所属类的Class等信息
        MethodSignature signature = (MethodSignature) jp.getSignature();
        //获取到该方法@LogInfo注解中的日志类型：枚举类LogType的值，保存到log实体中
        preLog.put("Method",signature.getMethod());
        //RequestContextHolder：持有上下文的Request容器,获取到当前请求的request
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest httpServletRequest = sra.getRequest();
        JSONObject jsonObject = new JSONObject();
        //存储uri到json中
        jsonObject.accumulate("uri", httpServletRequest.getRequestURI().toString());
        //这一步获取到的方法有可能是代理方法也有可能是真实方法
        Method m = ((MethodSignature) jp.getSignature()).getMethod();
        //通过真实方法获取该方法的参数名称
        LocalVariableTableParameterNameDiscoverer paramNames = new LocalVariableTableParameterNameDiscoverer();
        String[] parameterNames = paramNames.getParameterNames(m);
        //获取连接点方法运行时的入参列表
        Object[] args = jp.getArgs();
        //将参数名称与入参值一一对应起来
        Map<String, Object> params = new HashMap<>();
        for (int i = 0; i < parameterNames.length; i++) {
            params.put(parameterNames[i], args[i]);
        }
        //jsonObject.accumulate("params", params);

        //System.out.println("============================ 》Before : " + jsonObject.toString());

        logger.info("Log:执行之前"+params+jsonObject.toString());
    }
    @AfterReturning(value = "initPointCut()", returning  = "rtv")
    public void postLog(JoinPoint jp, Object rtv){

        //rtv为controller方法返回数据
        //JSONObject jsonObject = JSONObject.fromObject(rtv);

        //System.out.println("============================ 》AfterReturning : " + rtv);

        logger.info("============================ 》AfterReturning : " + rtv);
    }


    //@AfterThrowing("initPointCut()")
    public void afterThrowLog(){
        logger.debug("Log:目标方法的catch之后");
    }

}

