package com.ljb.ticket_book_ssm.service.imp;

import com.ljb.ticket_book_ssm.dao.ICinemaDao;
import com.ljb.ticket_book_ssm.dao.IUserDao;
import com.ljb.ticket_book_ssm.entity.Users;
import com.ljb.ticket_book_ssm.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public class UserService implements IUserService {
    @Autowired
    private IUserDao iUserDao;
    @Autowired
    private ICinemaDao iCinemaDao;
    /**
     * 注册
     * @param u
     * @return 1：成功，0：失败
     */
    public int register(Users u) {
        //先查询该用户是否存在,如果不等于1，即用户不在数据库中，则
        if (iUserDao.findOpenIdIfExisted(u.getOpenid()) != null){
            return 0;
        }else{
            iUserDao.save(u);
            return 1;
        }
    }
    /**
     * 获取用户信息
     * @param openId
     * @return Users对象信息
     */
    public Users getUser(String openId){
        //判断用户的存在性
        if (iUserDao.findOpenIdIfExisted(openId) != null){
            //查询
            return iUserDao.findUserByOpenId(openId);
        }
        return null;
    }

    /**
     * 寻找用户附近的影院
     * @param lon
     * @param lat
     * @param page
     * @return
     */
    public List<Map<String, Object>> findNearCinemaByLL(double lon, double lat, int page){
        if (lon <0 || lat<0 || page<0){
            return null;
        }
        //不知道怎么判断lon，lat为空，所以try一下
        try {
            return iCinemaDao.findCinemaByLL(lon,lat,(page-1)*10,page*10);
        }catch (Exception e){
            return null;
        }
    }



}
