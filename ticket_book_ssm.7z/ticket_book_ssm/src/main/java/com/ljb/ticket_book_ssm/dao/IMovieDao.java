package com.ljb.ticket_book_ssm.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;
import java.util.Map;
@Mapper
@Repository
public interface IMovieDao {
    /**
     * 判断电影是否存在数据库中
     * @param CName
     * @return true,false
     */
    String findMovieIfExistedByCName(String CName);
    /**
     * 搜索电影
     * @param cName
     * @return 名字最像的电影前10的ListMap
     */
    List<Map<String, Object>> searchMovieByCName(String cName);
    /**
     * 根据页数查询电影信息
     * @param page
     * @param ifRelease 是否上映,1是,0否
     * @return moviesListMap，字段有m_id,c_name,type,actor,start_date
     */
    List<Map<String, Object>> getMoviesByPage(int page,int pageIndex,int ifRelease);
    /**
     * 查询电影详细信息
     * @param mId
     * @return Map
     */
    Map<String,Object> getMovieDetailByMid(int mId);
    /**
     * 查询某电影院上映表上的电影信息
     * @param cId
     * @param preDate
     * @param aftDate
     * @return
     */
    List<Map<String,Object>> findMovieByCidAndDate(int cId,
                                                   Date preDate,
                                                   Date aftDate);

    /**
     * 选择电影获取该电影最近的电影院
     * @param mid
     * @param preDate
     * @param aftDate
     * @return
     */
    List<Map<String,Object>> getCinemaScheduleByMid(int mid,double lon, double lat,Date preDate,
                                                      Date aftDate);
}
