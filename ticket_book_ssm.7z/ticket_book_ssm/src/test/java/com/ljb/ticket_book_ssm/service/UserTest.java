package com.ljb.ticket_book_ssm.service;

import com.ljb.ticket_book_ssm.entity.Users;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserTest {
    @Autowired
    private IUserService iUserService;
    @Test
    void register(){
        Users u  = new Users("2","1",1,"1","1","1","1","1");
        System.out.println(iUserService.register(u));
    }
    @Test
    void getUser(){
        System.out.println(iUserService.getUser("2"));
    }
    @Test
    void findNearCinemaByLL(){
        System.out.println(iUserService.findNearCinemaByLL(113.33418,23.12675,1));
    }

}
