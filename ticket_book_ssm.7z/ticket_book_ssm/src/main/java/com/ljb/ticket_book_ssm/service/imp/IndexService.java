package com.ljb.ticket_book_ssm.service.imp;

import com.ljb.ticket_book_ssm.dao.ICinemaDao;
import com.ljb.ticket_book_ssm.dao.IMovieDao;
import com.ljb.ticket_book_ssm.service.IIndexService;
import com.ljb.ticket_book_ssm.util.base;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;
@Service
public class IndexService extends base implements IIndexService {
    @Autowired
    private IMovieDao iMovieDao;
    @Autowired
    private ICinemaDao iCinemaDao;
    /**
     * 查询某一页电影简述信息
     * @param page
     * @param ifRelease 是否发布，1：yes，0：No
     * @return 电影信息的JsonArray，一页10部电影
     */
    public List<Map<String, Object>> getMoviesByPage(int page,int ifRelease) {
        return iMovieDao.getMoviesByPage((page-1)*10,page*10,ifRelease);
    }


    /**
     * 搜索电影简述信息
     * @param name
     * @return
     */
    public List<Map<String, Object>> searchMoviesByName(String name){
        if (name == null){
            return null;
        }
        return iMovieDao.searchMovieByCName(name);

    }

    public List<Map<String, Object>> searchCinemaByLL(String cName,
                                                      double lon,
                                                      double lat,
                                                      int page){
        if (cName == null){
            return null;
        }
        return iCinemaDao.searchCinemaByLL(cName,lon,lat,(page-1)*10,page*10);
    }
    /**
     * 查询电影详细信息
     * @param mId
     * @return
     */
    public Map<String, Object> getMovieDetailByMid(int mId){
        return iMovieDao.getMovieDetailByMid(mId);


    }

    /**
     * 获取最近3天牟家电影院的上映电影信息
     * @param c_id
     * @return
     */
    public List<Map<String, Object>> getCinemaScheduleByCid(int c_id){
        List<Map<String, Object>> resultListMap = null;
        if (c_id <0){
            return null;
        }else {
            try {
                Date date = new Date();
                resultListMap = iMovieDao.findMovieByCidAndDate(c_id,addAndSubtractDaysByGetTime(date,0),addAndSubtractDaysByGetTime(date,3));
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
        return resultListMap;
    }

    /**
     * 选择电影获取该电影最近的电影院
     * 先找到该电影时间表信息，然后再从中去寻找最近的电影院。
     * @param m_id
     * @return
     */
    public List<Map<String, Object>> getCinemaScheduleByMid(int m_id,double lon, double lat){
        List<Map<String, Object>> resultListMap = null;
        if (m_id <0){
            return null;
        }else {
            try {
                Date date = new Date();
                resultListMap = iMovieDao.getCinemaScheduleByMid(m_id,lon,lat,addAndSubtractDaysByGetTime(date,0),addAndSubtractDaysByGetTime(date,3));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return resultListMap;
    }
}
