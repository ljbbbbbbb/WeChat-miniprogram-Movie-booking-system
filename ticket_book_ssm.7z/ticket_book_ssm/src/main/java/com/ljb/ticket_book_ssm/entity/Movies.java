package com.ljb.ticket_book_ssm.entity;


import lombok.Data;

import java.util.Date;
@Data
public class Movies {
    private int m_id,release_status,box,play_mintues;
    private String c_name,e_name,type,intro,intro_href,actor,role,a_href,photo_href,make_region,plat_region_id;
    private Date start_date,end_date;

}
