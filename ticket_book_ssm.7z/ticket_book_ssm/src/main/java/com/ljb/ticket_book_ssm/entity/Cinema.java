package com.ljb.ticket_book_ssm.entity;


import lombok.Data;

@Data
public class Cinema {

  private long cId;
  private String cName;
  private String location;
  private double lon;
  private double lat;

  public Cinema(String cName, String location, double lon, double lat) {
    this.cName = cName;
    this.location = location;
    this.lon = lon;
    this.lat = lat;
  }

  public Cinema() {
  }
}
