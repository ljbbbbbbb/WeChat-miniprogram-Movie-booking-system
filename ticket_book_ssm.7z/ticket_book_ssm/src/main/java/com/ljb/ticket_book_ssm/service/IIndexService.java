package com.ljb.ticket_book_ssm.service;

import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.util.List;
import java.util.Map;

public interface IIndexService {
    /**
     * 查询某一页电影简述信息
     * @param page
     * @param ifRelease 是否发布，1：yes，0：No
     * @return 电影信息的JsonArray，一页10部电影
     */
    List<Map<String, Object>> getMoviesByPage(int page, int ifRelease);
    /**
     * 搜索电影简述信息
     * @param name
     * @return
     */
    List<Map<String, Object>> searchMoviesByName(String name);

    /**
     * 搜索附近电影院
     * @param cName
     * @param lon
     * @param lat
     * @param page
     * @return
     */
    List<Map<String, Object>> searchCinemaByLL(String cName,
                                               double lon,
                                               double lat,
                                               int page);
    /**
     * 查询电影详细信息
     * @param mId
     * @return
     */
    Map<String, Object> getMovieDetailByMid(int mId);
    /**
     * 获取每一天牟家电影院的上映电影信息
     * @param c_id
     * @return
     */
    List<Map<String, Object>> getCinemaScheduleByCid(int c_id);

    /**
     * 选择电影获取该电影最近的电影院
     * @param m_id
     * @param lon
     * @param lat
     * @return
     */
    List<Map<String,Object>> getCinemaScheduleByMid(int m_id, double lon, double lat);


}
