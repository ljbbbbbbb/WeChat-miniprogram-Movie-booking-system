package com.ljb.ticket_book_ssm.dao;

import com.ljb.ticket_book_ssm.entity.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
@Mapper
@Repository
public interface IOrderDao {
    /**
     * 判断orderId订单是否存在
     * @param orderId
     * @return
     */
    int findOrderIdIfExistedByOrderIdAndOpenId(String openId,int orderId);
    /**
     * 查看订单
     * @param OpenId
     * @param page
     * @return
     */
    List<Map<String, Object>> getUserOrderByOpenId(String OpenId, int page,int pageIndex);

    /**
     * 查看订单详情
     * @param orderId
     * @return
     */
    Map<String, Object> getOrderDetailByOrderId(int orderId);
    /**
     * 查看orderCode的订单状态
     * @param orderCode
     * @return
     */
    Integer findOrderStatusByOrderCode(String orderCode);

    /**
     * 查看某用户下单后的订单状态。
     * @param openId
     * @param orderCode
     * @return 订单状态
     */
    Integer findOrderStatusByOpenIdAndOrderCode(String openId,String orderCode);
    /**
     * 获取某一场电影被订座位
     * @param sid
     * @return
     */
    List<Map<String, Object>> getPurchasedSeat(int sid);
    /**
     * 将生成的订单保存到数据库
     * @param order
     * @return 1:保存成功 -1：保存失败
     */
    void save(@Param("order") Order order);
    /**
     * （针对用户）根据orderId去修改订单的订单状态。
     * @param orderId
     * @param status
     * @return 0:未付未订，1:已订未付 2.已订已付 3.已取
     */
    Integer updateOrderStatus(int orderId,int status);

    /**
     * 查询订单id
     * @param openId
     * @param orderCode
     * @return
     */
    Integer findOrderId(String openId,String orderCode);

    /**
     * 更新取票码
     * @param orderId
     * @param tt_code
     * @return
     */
    Integer updateOrderTtcode(int orderId,int tt_code);

    /**
     * 修改orderStatus =2 和tt_code
     * @param orderId
     * @param tt_code
     * @return
     */
    Integer payForTicket(int orderId,int tt_code);
    /**
     * 退款(orderStatsu =5,finish_time = now())
     * @param orderId
     * @return
     */
    int refund(int orderId);
}
