package com.ljb.ticket_book_ssm.entity;

import lombok.Data;

import java.util.Date;

@Data
public class Order {
    private int order_id,tt_code,order_status,s_id,row,column;
    private String u_openid,order_code;
    private Date create_time,pay_time,finish_time;
    private float price;

    public Order() {
    }

    public Order(int s_id, int row, int column, String u_openid, String order_code, Date create_time, Date pay_time, Date finish_time, float price) {
        this.s_id = s_id;
        this.row = row;
        this.column = column;
        this.u_openid = u_openid;
        this.order_code = order_code;
        this.create_time = create_time;
        this.pay_time = pay_time;
        this.finish_time = finish_time;
        this.price = price;
    }
    public Order(int s_id, int row, int column, String u_openid, String order_code, Date create_time, Date pay_time, Date finish_time) {
        this.s_id = s_id;
        this.row = row;
        this.column = column;
        this.u_openid = u_openid;
        this.order_code = order_code;
        this.create_time = create_time;
        this.pay_time = pay_time;
        this.finish_time = finish_time;
    }

    public Order(int s_id, int row, int column, String u_openid) {
        this.s_id = s_id;
        this.row = row;
        this.column = column;
        this.u_openid = u_openid;
    }

    public Order(int order_id, int tt_code, int order_status, int s_id, int row, int column, String u_openid, String order_code, Date create_time, Date pay_time, Date finish_time, float price) {
        this.order_id = order_id;
        this.tt_code = tt_code;
        this.order_status = order_status;
        this.s_id = s_id;
        this.row = row;
        this.column = column;
        this.u_openid = u_openid;
        this.order_code = order_code;
        this.create_time = create_time;
        this.pay_time = pay_time;
        this.finish_time = finish_time;
        this.price = price;
    }
}
