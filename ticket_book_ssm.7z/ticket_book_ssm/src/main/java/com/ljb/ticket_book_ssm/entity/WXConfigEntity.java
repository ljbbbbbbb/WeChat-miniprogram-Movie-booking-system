package com.ljb.ticket_book_ssm.entity;

import lombok.Data;

@Data
public class WXConfigEntity {
    private String appId;
    private String noncestr,signature;
    private int timestamp;

    public WXConfigEntity(String appId, String noncestr, String signature, int timestamp) {
        this.appId = appId;
        this.noncestr = noncestr;
        this.signature = signature;
        this.timestamp = timestamp;
    }

    public WXConfigEntity() {
    }
}
