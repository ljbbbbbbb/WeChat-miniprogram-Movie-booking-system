package com.ljb.ticket_book_ssm.entity;

import lombok.Data;

@Data
public class Users {

  private String openid;
  private String nickname = "";
  private Integer sex = 0;
  private String language = "";
  private String city = "";
  private String province = "";
  private String country = "";
  private String headimgurl = "";

  public Users(String openid, String nickname, Integer sex, String language, String city, String province, String country, String headimgurl) {
    this.openid = openid;
    this.nickname = nickname;
    this.sex = sex;
    this.language = language;
    this.city = city;
    this.province = province;
    this.country = country;
    this.headimgurl = headimgurl;
  }

  public Users(String nickName, Integer gender, String language, String city, String province, String country, String avatarUrl) {
    this.nickname = nickname;
    this.sex = gender;
    this.language = language;
    this.city = city;
    this.province = province;
    this.country = country;
    this.headimgurl = avatarUrl;
  }
}
