package com.ljb.ticket_book_ssm.controller;

import com.ljb.ticket_book_ssm.service.IIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/index" ,headers = "Accept=application/json;charset=UTF-8")
@ResponseBody
public class IndexController {
    @Autowired
    private IIndexService iIndexService;
    @RequestMapping("/getMovie")
    public List<Map<String, Object>> getMoviesByPage(int page){
        int ifRelease = 2;
        return iIndexService.getMoviesByPage(page,2);
    }
    @RequestMapping("/getComingMovie")
    public List<Map<String, Object>> getComingMoviesByPage(int page){
        int ifRelease = 1;
        return iIndexService.getMoviesByPage(page,1);
    }
    @RequestMapping("/searchMovie")
    public List<Map<String, Object>> searchMoviesByName(String name){
        return iIndexService.searchMoviesByName(name);
    }
    @RequestMapping("/searchCinema")
    public List<Map<String, Object>> searchCinema(String cName,double lon,double lat,int page){
        return iIndexService.searchCinemaByLL(cName,lon,lat,1);
    }
    @RequestMapping("/getMovieDetail")
    public Map<String, Object> getMovieDetailByMid(int mId){
        return iIndexService.getMovieDetailByMid(mId);
    }
    @RequestMapping("/getMovieSchedule")
    public List<Map<String, Object>> getMovieScheduleByCid(int cId){
        return iIndexService.getCinemaScheduleByCid(cId);
    }
    //选择电影后查询附近的该电影上映的电影院
    @RequestMapping(value = "/getLocalCinemaScheduleByMid")
    public List<Map<String, Object>> getLocalCinemaScheduleByMid(int mId, double lon, double lat){
        return iIndexService.getCinemaScheduleByMid(mId, lon, lat);
    }
}
