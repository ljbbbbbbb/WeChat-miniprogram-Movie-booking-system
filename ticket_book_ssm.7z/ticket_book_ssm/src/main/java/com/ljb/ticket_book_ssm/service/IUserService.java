package com.ljb.ticket_book_ssm.service;

import com.ljb.ticket_book_ssm.entity.Users;

import java.util.List;
import java.util.Map;

public interface IUserService {
    /**
     * 注册
     * @param u
     * @return 1：成功，0：失败
     */
    int register(Users u) ;
    /**
     * 获取用户信息
     * @param openId
     * @return Users对象信息
     */
    Users getUser(String openId);

    /**
     * 寻找用户附近的影院
     * @param lon
     * @param lat
     * @param page
     * @return
     */
    List<Map<String, Object>> findNearCinemaByLL(double lon, double lat, int page);


}
